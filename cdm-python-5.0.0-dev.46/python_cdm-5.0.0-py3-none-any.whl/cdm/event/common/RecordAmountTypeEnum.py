from enum import Enum

all = ['RecordAmountTypeEnum']
  
class RecordAmountTypeEnum(Enum):
  """
  The enumeration of the account level for the billing summary.
  """
  ACCOUNT_TOTAL = "AccountTotal"
  GRAND_TOTAL = "GrandTotal"
  PARENT_TOTAL = "ParentTotal"
