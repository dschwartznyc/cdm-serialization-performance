from enum import Enum

all = ['PerformanceTransferTypeEnum']
  
class PerformanceTransferTypeEnum(Enum):
  """
  The enumerated values to specify the origin of a performance transfer
  """
  COMMODITY = "Commodity"
  CORRELATION = "Correlation"
  DIVIDEND = "Dividend"
  EQUITY = "Equity"
  INTEREST = "Interest"
  VARIANCE = "Variance"
  VOLATILITY = "Volatility"
