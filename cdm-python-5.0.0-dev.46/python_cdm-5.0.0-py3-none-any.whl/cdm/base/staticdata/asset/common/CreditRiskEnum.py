from enum import Enum

all = ['CreditRiskEnum']
  
class CreditRiskEnum(Enum):
  """
  Represents an enumeration list to identify tranched or untranched credit risk.
  """
  TRANCHED_CREDIT_RISK = "TranchedCreditRisk"
  """
  Indicates tranched credit risk, including securitizations.
  """
  UNTRANCHED_CREDIT_RISK = "UntranchedCreditRisk"
  """
  Indicates tranched credit risk, including repackagings.
  """
