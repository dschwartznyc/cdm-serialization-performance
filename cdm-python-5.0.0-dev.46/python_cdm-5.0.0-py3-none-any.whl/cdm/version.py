version = (5,0,0,0)
version_str = '5.0.0-0'
__version__ = '5,0,0'
__build_time__ = '2023-10-26T14:02:09.18825'